import { NextRequest, NextResponse } from 'next/server'
import { connectDb } from '@/lib/db'
import { opportunitySchema } from '@/lib/schemas'
import { requireAuth, handleApiError } from '@/lib/middleware'
import { ApiError, ERROR_CODES, successResponse } from '@/lib/api-response'
import { parseBody, queryParam, serialize, objectId } from '@/lib/route-utils'
import { createPaginatedResponse, getPaginationParams } from '@/lib/helpers'
import { sendRolePushNotification } from '@/lib/push-notifications'

export async function GET(request: NextRequest) {
  try {
    const page = Number(queryParam(request, 'page', '1'));
    const limit = Number(queryParam(request, 'limit', '20'));
    const pagination = getPaginationParams(page, limit);

    const filter: Record<string, unknown> = {};
    const mine = queryParam(request, 'mine');
    const createdBy = queryParam(request, 'createdBy');

    if (mine === 'true') {
      const auth = await requireAuth(request);
      filter.createdBy = auth.userId;
    } else if (createdBy) {
      filter.createdBy = createdBy;
    } else {
      filter.status = 'open';
      filter.deadline = { $gte: new Date() };
    }

    const tag = queryParam(request, 'tag') || queryParam(request, 'category');
    if (tag && tag !== 'All') {
      const regex = { $regex: tag, $options: 'i' };
      filter.$or = [
        { tags: tag },
        { category: regex },
        { productionServices: regex },
        { production_services: regex },
        { requirements: regex },
      ];
    }

    const search = queryParam(request, 'search');
    if (search && search.trim()) {
      const searchRegex = { $regex: search.trim(), $options: 'i' };
      filter.$or = [
        ...(Array.isArray(filter.$or) ? (filter.$or as unknown[]) : []),
        { title: searchRegex },
        { description: searchRegex },
        { category: searchRegex },
        { city: searchRegex },
      ];
    }

    const city = queryParam(request, 'city');
    if (city && city.trim()) {
      filter.$and = [
        ...(Array.isArray(filter.$and) ? (filter.$and as unknown[]) : []),
        {
          $or: [
            { city: { $regex: city.trim(), $options: 'i' } },
            { 'location.city': { $regex: city.trim(), $options: 'i' } }
          ]
        }
      ];
    }

    const db = await connectDb();
    const collection = db.collection('opportunities');
    const total = await collection.countDocuments(filter);
    const data = await collection.find(filter).sort({ createdAt: -1 }).skip(pagination.skip).limit(pagination.limit).toArray();

    return NextResponse.json(successResponse(createPaginatedResponse(serialize(data), pagination.page, pagination.limit, total)));
  } catch (error) { return handleApiError(error); }
}

export async function POST(request: NextRequest) {
  try {
    const auth = await requireAuth(request); if (auth.role !== 'business') throw new ApiError(ERROR_CODES.FORBIDDEN, 403, 'Only businesses can create opportunities')
    const input = await parseBody(request, opportunitySchema)
    const rawPriceOnCall = Boolean(input.isPriceOnCall || input.is_price_on_call)
    const budgetMax = input.budget?.max ?? 0
    const budgetMin = input.budget?.min ?? 0
    const isPriceOnCall = rawPriceOnCall || (budgetMax <= 0 && budgetMin <= 0)
    if (!isPriceOnCall && budgetMax > 0 && budgetMax < budgetMin) {
      throw new ApiError(ERROR_CODES.VALIDATION_ERROR, 400, 'Maximum budget must be at least the minimum budget')
    }
    const deadline = new Date(input.deadline); if (deadline <= new Date()) throw new ApiError(ERROR_CODES.VALIDATION_ERROR, 400, 'Deadline must be in the future')
    const db = await connectDb()
    const user = await db.collection('users').findOne({ _id: objectId(auth.userId) })

    // Check opportunity quota if defined
    if (user && user.availableOpportunityPosts !== undefined && user.availableOpportunityPosts <= 0) {
      throw new ApiError(
        ERROR_CODES.FORBIDDEN,
        403,
        'Opportunity posting limit reached. Please choose a plan or enter a promo code to post more.'
      )
    }

    const bProfile = await db.collection('businessProfiles').findOne({ userId: auth.userId })
    const resolvedBusinessName = bProfile?.companyName || (user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : '') || input.businessName || 'Business Account'
    const now = new Date(); const doc = { ...input, isPriceOnCall, businessName: resolvedBusinessName, createdBy: auth.userId, status: 'open', deadline, createdAt: now, updatedAt: now }
    const result = await db.collection('opportunities').insertOne(doc)
    const insertedId = result.insertedId.toString()

    // Decrement post quota if tracked
    if (user && user.availableOpportunityPosts && user.availableOpportunityPosts > 0) {
      await db.collection('users').updateOne(
        { _id: user._id },
        { $inc: { availableOpportunityPosts: -1 } }
      )
    }

    // Trigger push notification to matching role talents
    const targetRole = input.targetRole || input.target_role || 'model'
    sendRolePushNotification({
      targetRole,
      opportunityId: insertedId,
      title: doc.title,
      businessName: resolvedBusinessName,
      city: doc.city,
      preferredGender: input.preferredGender || undefined,
      preferredAgeMin: input.preferredAgeMin || undefined,
      preferredAgeMax: input.preferredAgeMax || undefined,
    }).catch((err) => console.error('[FCM] Push notification error:', err))

    return NextResponse.json(successResponse(serialize({ _id: result.insertedId, ...doc })), { status: 201 })
  } catch (error) { return handleApiError(error) }
}
