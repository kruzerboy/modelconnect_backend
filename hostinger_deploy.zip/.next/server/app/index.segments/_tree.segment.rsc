:HL["/_next/static/css/a673cc74c613da05.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"a-qdPrSJ5U5P3XRPmDfhq"}
